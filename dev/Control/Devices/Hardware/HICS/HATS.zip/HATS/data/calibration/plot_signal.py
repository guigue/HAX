#Script to read data from the windowed_dft
#Will plot the windowed signal
import numpy as np
import matplotlib.pyplot as plt

fsignal = open("signal_array.txt","r")
sampling_frequency = float(fsignal.readline().split(" ")[2]) #frequency of sampling
interval_sampling = 1/sampling_frequency
#frequency increment
signal_lenght = int(fsignal.readline().split(" ")[2]) #number of data points 
df = 1/(signal_lenght*interval_sampling)
signal = list(fsignal.readline().split(" ")) #read the file with data
signal = signal[:-1] #remove the last item because always is ''

for i in range(len(signal)):
	signal[i] = float(signal[i])

time_space = interval_sampling*np.array(range(len(signal))) #array with time 

plt.plot(time_space,signal)
plt.xlabel("Time in seconds")
plt.ylabel("Amplitude")
plt.title(f'Windowed signal with \nsampling frequency = {sampling_frequency:.4} and signal_lenght = {signal_lenght}')
plt.savefig("plots/Flattop_signal.png")
