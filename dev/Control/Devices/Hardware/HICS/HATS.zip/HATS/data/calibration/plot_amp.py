import numpy as np
import matplotlib.pyplot as plt

fmod = open(f"mod_array.txt","r")
sampling_frequency = float(fmod.readline().split(" ")[2]) #frequency of sampling
interval_sampling = 1/sampling_frequency
#frequency increment
signal_lenght = int(fmod.readline().split(" ")[2]) #number of data points 
df = 1/(signal_lenght*interval_sampling)
mod = list(fmod.readline().split(" ")) #read the file with data
mod = mod[:-1] #remove the last item because always is ''

for j in range(len(mod)):
    mod[j] = 1/signal_lenght*float(mod[j])

print(max(mod))
frequency_space = (sampling_frequency/signal_lenght)*np.array(range(int(np.floor(signal_lenght/2)+1)))
plt.plot(frequency_space,mod)
plt.xlabel("Frequency in Hz")
plt.ylabel("Amplitude")
plt.title(f'DFT of the window \nsampling frequency = {sampling_frequency:.4} and signal_lenght = {signal_lenght}')
plt.savefig(f"plots/Flattop_amp.png")
