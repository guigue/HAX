for i in range(1000):
	print(f"file 'amplitude_window_{i}.png'")
