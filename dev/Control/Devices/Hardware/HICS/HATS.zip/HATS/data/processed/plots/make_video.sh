#! /bin/bash

ffmpeg -y -r 24 -f concat -safe 0 -i file_list -c:v libx264 -vf "fps=25,format=yuv420p" out.mp4
