/*
 * ad7770.h
 *
 * Created: 12/07/2019 15:15:30
 *  Author: User
 */ 


#ifndef ADC_H_
#define ADC_H_

//-----------------------------------------------------------
// DEFINITIONS
// ----------------------------------------------------------

#define AD7770_NUMBER_OF_REGISTERS 101	// Registers address 0x00 to 0x64

#define ADC_1CH_BUFFER_SIZEOF (1+3)	// header 8-bit + adc 24-bit)
#define ADC_8CH_BUFFER_SIZEOF (8*(ADC_1CH_BUFFER_SIZEOF)) // 8 canais x (header 8-bit + adc 24-bit)

//#define ADC_BUFFER_LINES	1000	// 1000 amostras (ODR = 1KHz sao 1000 amostras/segundo)
#define ADC_BUFFER_LINES	500		// 500 amostras para diminuir buffer por causa de husec 64-bit (ao adicionar causou overflow memoria SRAM interna)

//-----------------------------------------------------------
// VARS PROTOTYPES
// ----------------------------------------------------------

// ADC CHANNEL BUFFER DATA
typedef struct
{	uint32_t ulSample;

	uint32_t ulTimestamp_sec;	// Timestamp segundos
	uint16_t usTimestamp_ms;	// Timestamp milesegundos

	uint64_t u64husec;			// Timestamp HUSECS

	uint8_t  raw[ADC_1CH_BUFFER_SIZEOF];	
} CHBUF_DATA;
extern CHBUF_DATA chbuf_data1[ADC_BUFFER_LINES];		// Channel buffer data 1
extern CHBUF_DATA chbuf_data2[ADC_BUFFER_LINES];		// Channel buffer data 2

// ADC CHANNEL BUFFER CONTROL
typedef struct
{	uint8_t byTrigger;
	uint8_t byBuff12;	// Buffer em uso onde as amostras estao sendo copiadas (0=chbuf_data1; 1=chbuf_data2)
	uint16_t wIdx;
} CHBUF_CTRL;
extern CHBUF_CTRL chbuf_ctrl;	// Channel buffer control

//-----------------------------------------------------------
// FUNCTIONS PROTOTYPES
// ----------------------------------------------------------

void ADC_Reset(void);
void ADC_SPI_init(void);

void ADC_ReadAllRegisters(void);

void ADC_Config(void);

void ADC_EnableReadADConSDO(void);
void ADC_DisableReadADConSDO(void);

void ADC_ReadADC(void);

void ADC_ReadADC_isr(const uint32_t id, const uint32_t index);

void ADC_Task(void *pvParameters);

#endif /* ADC_H_ */